/**
 * 
 */
/**
 * 
 */
module Kniffel {
	requires java.desktop;
}