package datenspeicherung;

public class BestenlisteSpeicher {

}
