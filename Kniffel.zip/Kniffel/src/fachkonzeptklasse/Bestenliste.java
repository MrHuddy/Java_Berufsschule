package fachkonzeptklasse;
import datenspeicherung.*;
public class Bestenliste {

	
	private BestenlisteSpeicher derBestenlisteSpeicher;
	
	public Bestenliste() {
		derBestenlisteSpeicher = new BestenlisteSpeicher();
	}
	
}
