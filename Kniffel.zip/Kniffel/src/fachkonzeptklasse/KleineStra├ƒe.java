package fachkonzeptklasse;

public class KleineStraße extends Figur{

	@Override
	public void trageEin(int[] pAugenZahl) {
		// TODO Auto-generated method stub
		
	}

}
